-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 14, 2020 at 12:44 PM
-- Server version: 5.7.23
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `broadreach`
--

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `getCURSORDATA`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `getCURSORDATA` ()  BEGIN
	DECLARE finished int default 0; DECLARE cellnos varchar(30) default " "; 
	DECLARE cellno_list varchar(500) default " cellNumber: "; 
    DECLARE patient_data CURSOR FOR SELECT mobileNo FROM patient; 
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1; 
    
    OPEN patient_data; 
    get_patient_cellno:LOOP 
    FETCH patient_data INTO cellnos; 
    
    IF finished = 1 THEN LEAVE get_patient_cellno; 
    END IF; 
    
    SET cellno_list = CONCAT(cellno_list,", ",cellnos); 
    END LOOP get_patient_cellno; 
    CLOSE patient_data; 
    
    SELECT cellno_list;
END$$

--
-- Functions
--
DROP FUNCTION IF EXISTS `checkEmptyRooms`$$
CREATE DEFINER=`root`@`localhost` FUNCTION `checkEmptyRooms` (`assignedTo` INT(5)) RETURNS VARCHAR(200) CHARSET latin1 BEGIN
	IF room.assignedTo is Null THEN
    return concat(room.roomNo, ': Room available');
    else
    return 'no rooms available';
    end IF;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `all diagnostic test details`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `all diagnostic test details`;
CREATE TABLE IF NOT EXISTS `all diagnostic test details` (
`testID` int(5)
,`testType` varchar(10)
,`testConductor` int(5)
,`roomNo` int(3)
,`patientID` int(5)
,`fname` varchar(30)
,`comments` varchar(255)
,`date` date
,`time` time
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `all patient appointments in detail`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `all patient appointments in detail`;
CREATE TABLE IF NOT EXISTS `all patient appointments in detail` (
`appointmentID` int(5)
,`appointmentType` varchar(15)
,`date` date
,`time` time
,`patientID` int(5)
,`fname` varchar(30)
,`staffID` int(5)
,`lname` varchar(30)
);

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

DROP TABLE IF EXISTS `appointment`;
CREATE TABLE IF NOT EXISTS `appointment` (
  `appointmentID` int(5) NOT NULL AUTO_INCREMENT COMMENT 'unique identifier',
  `appointmentType` varchar(15) NOT NULL COMMENT 'type of appointment scheduled',
  `date` date NOT NULL COMMENT 'date of appointment',
  `time` time NOT NULL COMMENT 'time of appointment',
  `patientID` int(5) NOT NULL COMMENT 'patient to attend scheduled appointment',
  `chwID` int(5) NOT NULL COMMENT 'community healthcare worker scheduled',
  PRIMARY KEY (`appointmentID`),
  KEY `patientID` (`patientID`,`chwID`),
  KEY `chwID` (`chwID`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1 COMMENT='Scheduled appointments';

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`appointmentID`, `appointmentType`, `date`, `time`, `patientID`, `chwID`) VALUES
(24, 'PMTCT', '2020-03-19', '10:15:00', 4720, 3227),
(25, 'PMTCT', '2020-03-19', '10:15:00', 4720, 3227),
(26, 'CHW', '2020-03-19', '12:35:00', 4724, 3227),
(27, 'CHW', '2020-03-19', '14:25:00', 4734, 3228),
(28, 'CHW', '2020-03-20', '10:15:00', 4720, 3228),
(29, 'PMTCT', '2020-03-20', '12:35:00', 4726, 3227),
(30, 'Diabetes Clinic', '2020-03-20', '14:25:00', 4732, 3229),
(31, 'Diabetes Clinic', '2020-03-21', '10:15:00', 4725, 3229),
(32, 'CHW', '2020-03-21', '12:35:00', 4726, 3227),
(34, 'clinic', '2020-06-13', '17:18:00', 4721, 3222),
(40, 'clinic', '2020-06-13', '17:18:00', 4721, 3222),
(41, 'PMTCT', '2020-03-21', '12:35:00', 4724, 3227),
(42, 'CHW', '2020-03-25', '12:35:00', 4726, 3227),
(43, 'Diabetes Clinic', '2020-03-22', '14:25:00', 4732, 3229),
(44, 'CHW', '2020-03-23', '12:35:00', 4724, 3227);

--
-- Triggers `appointment`
--
DROP TRIGGER IF EXISTS `afterAppointmentInsert`;
DELIMITER $$
CREATE TRIGGER `afterAppointmentInsert` AFTER INSERT ON `appointment` FOR EACH ROW BEGIN
	IF NEW.appointmentType LIKE 'PMTCT' THEN 
 	INSERT INTO patientlist (mappingID, listID, chwID, patientID, appointmentID)
    VALUES (null, '3', NEW.chwID, NEW.patientID, NEW.appointmentID);
    END IF;
    
    	IF NEW.appointmentType LIKE 'CHW' THEN 
 	INSERT INTO patientlist (mappingID, listID, chwID, patientID, appointmentID)
    VALUES (null, '3', NEW.chwID, NEW.patientID, NEW.appointmentID);
    END IF;
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `convertAppointmentToUpper`;
DELIMITER $$
CREATE TRIGGER `convertAppointmentToUpper` BEFORE INSERT ON `appointment` FOR EACH ROW BEGIN
	SET NEW.appointmentType = UPPER( NEW.appointmentType );
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `diagnostictest`
--

DROP TABLE IF EXISTS `diagnostictest`;
CREATE TABLE IF NOT EXISTS `diagnostictest` (
  `testID` int(5) NOT NULL AUTO_INCREMENT COMMENT 'unique identifier',
  `testType` varchar(10) NOT NULL COMMENT 'Test to be conducted',
  `testConductor` int(5) NOT NULL COMMENT 'conductor of the test',
  `roomNo` int(3) NOT NULL COMMENT 'location of the department',
  `patientID` int(5) NOT NULL COMMENT 'patient of the test',
  `comments` varchar(255) DEFAULT NULL COMMENT 'results/findings',
  `date` date DEFAULT NULL COMMENT 'date test was conducted',
  `time` time DEFAULT NULL COMMENT 'time test was conducted',
  PRIMARY KEY (`testID`),
  KEY `testConductor` (`testConductor`,`roomNo`,`patientID`),
  KEY `roomNo` (`roomNo`),
  KEY `patientofAppointment` (`patientID`)
) ENGINE=InnoDB AUTO_INCREMENT=319 DEFAULT CHARSET=latin1 COMMENT='information of diagnostic test conducted';

--
-- Dumping data for table `diagnostictest`
--

INSERT INTO `diagnostictest` (`testID`, `testType`, `testConductor`, `roomNo`, `patientID`, `comments`, `date`, `time`) VALUES
(311, 'Radiology', 3232, 4, 4720, 'Ultrasound performed, secondary heartbeat found. Patient is approx 3 weeks pregnant.', '2020-03-15', '09:40:00'),
(312, 'Radiology', 3231, 8, 4726, 'ultrasound conducted, possible twins', '2020-03-17', '09:40:00'),
(313, 'Lab Test', 3233, 4, 4724, 'Xray scan conducted, left lung air pocket found. Possible tubercolosis case', '2020-03-16', '11:50:00'),
(314, 'Lab Test', 3233, 4, 4725, 'urinalysis test conducted. Low blood and results show signs of diabetes', '2020-03-17', '08:30:00'),
(315, 'Lab Test', 3234, 5, 4727, 'X-ray of bone structure, arm bone fractured, cast required.', '2020-03-17', '12:05:00'),
(316, 'Lab Test', 3235, 6, 4734, 'basic metabolic panel test conudcted, High blood pressure case found.', '2020-03-17', '14:40:00');

-- --------------------------------------------------------

--
-- Table structure for table `examination`
--

DROP TABLE IF EXISTS `examination`;
CREATE TABLE IF NOT EXISTS `examination` (
  `examID` int(5) NOT NULL AUTO_INCREMENT COMMENT 'unique identifier',
  `examinerID` int(5) NOT NULL COMMENT 'conductor of Examination - clinician',
  `patientID` int(5) NOT NULL COMMENT 'patient attending the exam',
  `comments` varchar(255) DEFAULT NULL COMMENT 'clinical findings of the examination',
  `date` date DEFAULT NULL COMMENT 'date of examination taken place',
  `time` time DEFAULT NULL COMMENT 'time of examination taken place',
  PRIMARY KEY (`examID`),
  KEY `examinerID` (`examinerID`,`patientID`),
  KEY `patientNo` (`patientID`)
) ENGINE=InnoDB AUTO_INCREMENT=11435 DEFAULT CHARSET=latin1 COMMENT='Information of examination';

--
-- Dumping data for table `examination`
--

INSERT INTO `examination` (`examID`, `examinerID`, `patientID`, `comments`, `date`, `time`) VALUES
(11262, 3221, 4720, 'Patient cannot sleep. Restless nights. Mood swings and inattentiveness found. Patient does not drink alcohol. Occupation: financial advisor. Medication prescribed ', '2020-03-18', '12:16:00'),
(11263, 3221, 4721, 'First time visit? yes\r\nissue: young male, cant excrete. Moderately fit, good shape.\r\nsubstance history: None\r\nOccupation: professional soccer player\r\nTreatment? Prescribed medication', '2020-03-16', '14:06:00'),
(11411, 3221, 4722, 'First time visit? yes \r\n issue: Throat sore, occasional chest pain \r\n substance history: none \r\n Occupation: police officer \r\n family history: Dad had HIV \r\n Treatment? Prescribed medication', '2020-03-15', '08:05:00'),
(11412, 3223, 4720, 'First time visit? No \r\n issue: Sleeplessness continues and nausea, mostly in the morning. No period \r\n substance history: Clean for 3 weeks \r\n Occupation\r\nfamily history: \r\n Treatment? Send to radiology and lab\r\n', '2020-03-15', '09:15:00'),
(11413, 3221, 4720, 'First time visit? No \r\nissue: Lab results evaluated. Pregnancy found. \r\nTreatment? Medication prescribed', '2020-03-16', '10:35:00'),
(11414, 3222, 4723, 'first visit \r\nissue: Hot flushes, sore throat, dry cough \r\nsubstance history: excessive alcohol use \r\nOccupation: salesman \r\n family history: clean \r\nTreatment? Medication prescribed', '2020-03-16', '11:20:00'),
(11415, 3221, 4724, 'First time visit? yes \r\nissue: Hot flushes, sore throat, dry cough \r\nsubstance history: Xanax used \r\nOccupation: lawyer \r\nfamily history: clean \r\nTreatment? Send to lab', '2020-03-16', '12:05:00'),
(11422, 3221, 4724, 'First time visit? No \r\nissue: pulmonary issue, disturbed lungs from lab assessment. TB signs found \r\n substance history: \r\n Occupation: \r\n family history: \r\n Treatment? Medication prescribed', '2020-03-16', '13:15:00'),
(11423, 3222, 4732, 'First visit \r\nissue: tired, passed out ocsnly @ home, possibly low blood sugar \r\nsubstance history: completed antibiotic \r\nOccupation: Branch manager \r\nfamily history: parents diabetes type 2 \r\nTreatment? Medication prescribed', '2020-03-16', '13:55:00'),
(11424, 3223, 4733, 'First time visit? Yes \r\nissue: Respiratory issues, low heart bpm \r\nsubstance history: Heroin used within 1 week \r\nOccupation: unemployed \r\nfamily history: none \r\nTreatment? Medication prescribed', '2020-03-16', '14:20:00'),
(11425, 3223, 4730, 'First time visit? Yes \r\nissue: Common cold \r\nsubstance history: flutex \r\n Occupation: software engineer \r\nfamily history: \r\nTreatment? Medication prescribed', '2020-03-16', '15:15:00'),
(11426, 3221, 4729, 'First time visit? yes \r\nissue: Common cold \r\n substance history: none \r\n Occupation: practitioner\r\nfamily history: \r\n Treatment?medication prescribed\r\n', '2020-03-16', '15:45:00'),
(11427, 3222, 4725, 'First time visit? yes \r\nissue: tired all the time, low blood, low sugar \r\n substance history: none \r\nOccupation: school teacher \r\n family history: \r\n\r\nTreatment? None yet, Sent to lab for analysis\r\n', '2020-03-17', '08:05:00'),
(11428, 3221, 4726, 'Patient cannot sleep. Restless nights. Mood swings and inattentiveness found. Patient does not drink alcohol. Occupation: financial advisor. Medication prescribed', '2020-03-17', '09:15:00'),
(11429, 3223, 4725, 'First time visit? no \r\n issue: Lab results, diabetes symptoms known \r\n substance history: \r\nOccupation: \r\nfamily history: great grandfather was diabetic type 1 \r\n Treatment? Medication prescribed ', '2020-03-17', '10:35:00'),
(11430, 3222, 4727, 'First time visit? yes \r\n issue: Arm pain, painful after skateboarding incident. \r\n substance history: brufen for pain \r\n Occupation: sales \r\nfamily history: \r\n\r\nTreatment? Pain medication prescribed, sent to lab for fracture check.\r\n', '2020-03-17', '11:20:00'),
(11431, 3222, 4728, 'First time visit? yes \r\nissue: Constipation issues. \r\nsubstance history: none \r\nOccupation: plumber \r\n family history: \r\nTreatment? Medication prescribed for excretion aid \r\n', '2020-03-17', '12:05:00'),
(11432, 3221, 4726, 'F First time visit? No \r\nissue: Lab results evaluated. Pregnancy found. \r\nTreatment? Medication \r\nprescribed Treatment? \r\n', '2020-03-17', '13:15:00'),
(11433, 3223, 4734, 'First time visit? yes \r\n issue: excessive drinking, possible liver failure, sent to lab \r\nsubstance history: contaminated alcohol \r\nOccupation: Bartender \r\nfamily history: Brother was a crack addict \r\n Treatment? Sent to lab for testing.', '2020-03-17', '14:15:00');

-- --------------------------------------------------------

--
-- Table structure for table `intervention`
--

DROP TABLE IF EXISTS `intervention`;
CREATE TABLE IF NOT EXISTS `intervention` (
  `interventionID` int(5) NOT NULL AUTO_INCREMENT COMMENT 'unique mapping of intervention',
  `patientID` int(5) NOT NULL COMMENT 'identifier of patient',
  `drugAdministered` varchar(35) NOT NULL COMMENT 'drug that was given to the patient',
  `comments` varchar(255) DEFAULT NULL COMMENT 'results / general comments',
  PRIMARY KEY (`interventionID`),
  KEY `patientID` (`patientID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `intervention`
--

INSERT INTO `intervention` (`interventionID`, `patientID`, `drugAdministered`, `comments`) VALUES
(1, 4720, 'Ambien (zolpidem)', 'Patient is sleeping easier. Still a bit resless but calmer.'),
(2, 4726, 'Ambien (zolpidem)', 'Patient has a bad reaction to the first dosage, informed her to eat before taking dosage'),
(3, 4724, 'Rifafour', 'Patient is lost 7 KG in the first week, multi vitamin given as extra');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
CREATE TABLE IF NOT EXISTS `message` (
  `messageID` int(5) NOT NULL AUTO_INCREMENT COMMENT 'unique identifier of message',
  `patientID` int(5) DEFAULT NULL COMMENT 'identifier of patient',
  `chwID` int(5) DEFAULT NULL COMMENT 'identifier of community healthcare worker',
  `messageType` varchar(30) NOT NULL COMMENT 'type of message being sent (also determines who it gets sent to )',
  `messageContent` varchar(255) NOT NULL COMMENT 'the message itself',
  `date` date NOT NULL COMMENT 'date message sent',
  `time` time NOT NULL COMMENT 'time message sent',
  PRIMARY KEY (`messageID`),
  KEY `patientID` (`patientID`,`chwID`),
  KEY `chwMessage` (`chwID`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1 COMMENT='message details';

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`messageID`, `patientID`, `chwID`, `messageType`, `messageContent`, `date`, `time`) VALUES
(15, 4720, NULL, 'Registration Confirmation', 'Hi Brandy, You have been registered on our Mom Connect System. Keep a look out for appointments and health messages', '2020-03-16', '10:49:00'),
(16, 4720, NULL, 'Reminder', 'Hi Brandy, Reminder you have a PMTCT appointment tommorow @10:15 19-03-2020', '2020-03-18', '13:49:00'),
(17, 4720, NULL, 'healthMessage', 'Hi Brandy, it is now 2 weeks into your pregnancy, we would like you to now consider using coconut oil to lubricate your stomach to ease the growth.', '2020-03-30', '12:18:00'),
(18, 4720, NULL, 'Confirmation of Appointment', 'Hi Brandy, Reminder you have a PMTCT appointment tommorow @10:15 19-03-2020', '2020-03-16', '13:49:00'),
(19, NULL, 3227, 'Reminder', 'Hi Renee, Reminder you have a PMTCT appointment tomorrow @10:15 19-03-2020', '2020-03-18', '13:49:00'),
(20, 4720, 3228, 'Missed Appointment', 'Hi Haley, Your client missed his appointment with you @14:25 19 March 2020', '2020-03-19', '15:20:00');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

DROP TABLE IF EXISTS `patient`;
CREATE TABLE IF NOT EXISTS `patient` (
  `patientID` int(5) NOT NULL AUTO_INCREMENT COMMENT 'unique identifier',
  `fname` varchar(30) NOT NULL COMMENT 'first name',
  `lname` varchar(30) NOT NULL COMMENT 'last name',
  `gender` varchar(10) NOT NULL COMMENT 'gender',
  `mobileNo` varchar(10) NOT NULL COMMENT 'contactNo',
  PRIMARY KEY (`patientID`)
) ENGINE=InnoDB AUTO_INCREMENT=4739 DEFAULT CHARSET=latin1 COMMENT='Patient''s details';

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`patientID`, `fname`, `lname`, `gender`, `mobileNo`) VALUES
(4720, 'Brandy', 'Spotts', 'Female', '0794713895'),
(4721, 'Joseph', 'Findley', 'Male', '0824278058'),
(4722, 'Catherine', 'Mortimer', 'Female', '0795354900'),
(4723, 'Bobby', 'Massey', 'Other', '0744379996'),
(4724, 'Rebekah', 'Clark', 'Other', '0628815317'),
(4725, 'Christopher', 'Lawrence', 'Male', '0748454866'),
(4726, 'Jessica', 'Pinto', 'Other', '0794713895'),
(4727, 'Susan', 'Houston', 'Female', '0876387338'),
(4728, 'David', 'Ortiz', 'Female', '0796047110'),
(4729, 'Justin', 'Carey', 'Other', '0723986755'),
(4730, 'Merle', 'Aguilar', 'Female', '0629511442'),
(4731, 'Grace', 'Stewart', 'Other', '0826230979'),
(4732, 'Floyd', 'Johnson', 'Male', '0792848994'),
(4733, 'Harold', 'Lawson', 'Male', '0874449242'),
(4734, 'Kent', 'Stern', 'Male', '0878735430');

-- --------------------------------------------------------

--
-- Table structure for table `patientexaminationrecord`
--

DROP TABLE IF EXISTS `patientexaminationrecord`;
CREATE TABLE IF NOT EXISTS `patientexaminationrecord` (
  `exRecordID` int(5) NOT NULL AUTO_INCREMENT COMMENT 'identifier of examination record',
  `patientID` int(5) NOT NULL COMMENT 'patient of Exam',
  `examID` int(5) NOT NULL COMMENT 'exam of patient',
  PRIMARY KEY (`exRecordID`),
  KEY `patientID` (`patientID`,`examID`),
  KEY `examReference` (`examID`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1 COMMENT='Record of all patients examinations';

--
-- Dumping data for table `patientexaminationrecord`
--

INSERT INTO `patientexaminationrecord` (`exRecordID`, `patientID`, `examID`) VALUES
(1, 4720, 11262),
(3, 4720, 11412),
(2, 4720, 11413),
(19, 4721, 11263),
(4, 4722, 11411),
(5, 4723, 11414),
(7, 4724, 11415),
(6, 4724, 11422),
(9, 4725, 11427),
(8, 4725, 11429),
(11, 4726, 11428),
(10, 4726, 11432),
(12, 4727, 11430),
(13, 4728, 11431),
(14, 4729, 11426),
(15, 4730, 11425),
(16, 4732, 11423),
(17, 4733, 11424),
(18, 4734, 11433);

-- --------------------------------------------------------

--
-- Table structure for table `patientlist`
--

DROP TABLE IF EXISTS `patientlist`;
CREATE TABLE IF NOT EXISTS `patientlist` (
  `mappingID` int(5) NOT NULL AUTO_INCREMENT COMMENT 'unique mapping of list',
  `listID` int(5) NOT NULL COMMENT 'unique identifier of list',
  `chwID` int(5) NOT NULL COMMENT 'identifier of community healthcare worker',
  `patientID` int(5) NOT NULL COMMENT 'identifier of patient',
  `appointmentID` int(5) NOT NULL COMMENT 'appointment reference',
  PRIMARY KEY (`mappingID`),
  KEY `chwID` (`chwID`,`patientID`,`appointmentID`),
  KEY `patientOnList` (`patientID`),
  KEY `appointmentScheduled` (`appointmentID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COMMENT='list of patients to be seen';

--
-- Dumping data for table `patientlist`
--

INSERT INTO `patientlist` (`mappingID`, `listID`, `chwID`, `patientID`, `appointmentID`) VALUES
(1, 1, 3227, 4720, 24),
(2, 1, 3227, 4720, 25),
(3, 2, 3228, 4724, 26),
(4, 3, 3229, 4720, 28),
(5, 1, 3227, 4726, 29),
(6, 1, 3227, 4726, 32),
(7, 3, 3222, 4721, 34),
(8, 3, 3227, 4724, 41),
(9, 3, 3227, 4726, 42),
(10, 3, 3227, 4724, 44);

-- --------------------------------------------------------

--
-- Table structure for table `patientrecord`
--

DROP TABLE IF EXISTS `patientrecord`;
CREATE TABLE IF NOT EXISTS `patientrecord` (
  `pRecord` int(5) NOT NULL AUTO_INCREMENT COMMENT 'identifier of patientRecord',
  `patientID` int(5) DEFAULT NULL COMMENT 'patient Identified',
  `testID` int(5) DEFAULT NULL COMMENT 'identifier of test conducted',
  `examID` int(5) DEFAULT NULL COMMENT 'identifier of exam conducted',
  `treatmentID` int(5) DEFAULT NULL COMMENT 'Identifier of assigned treatment',
  `prescriptionID` int(5) DEFAULT NULL COMMENT 'identifier of prescription',
  `interventionID` int(5) DEFAULT NULL COMMENT 'Identifier of intervention conducted',
  PRIMARY KEY (`pRecord`),
  KEY `patientID` (`patientID`,`testID`,`examID`,`treatmentID`,`prescriptionID`,`interventionID`),
  KEY `testRef` (`testID`),
  KEY `examRef` (`examID`),
  KEY `treatmentRef` (`treatmentID`),
  KEY `prescriptionRef` (`prescriptionID`),
  KEY `interventionRef` (`interventionID`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1 COMMENT='mappping of all records recorded that belong to the patient';

--
-- Dumping data for table `patientrecord`
--

INSERT INTO `patientrecord` (`pRecord`, `patientID`, `testID`, `examID`, `treatmentID`, `prescriptionID`, `interventionID`) VALUES
(4, 4720, NULL, NULL, NULL, NULL, 1),
(1, 4720, NULL, 11262, 2112, 642, NULL),
(3, 4720, NULL, 11413, 2115, 645, NULL),
(2, 4720, 311, 11412, NULL, NULL, NULL),
(5, 4721, NULL, 11263, 2113, 643, NULL),
(6, 4722, NULL, 11411, 2114, 644, NULL),
(7, 4723, NULL, 11414, 2116, 646, NULL),
(10, 4724, NULL, NULL, NULL, NULL, 3),
(9, 4724, NULL, 11422, 2117, 647, NULL),
(8, 4724, 313, 11415, NULL, NULL, NULL),
(12, 4725, NULL, 11429, 2123, 653, NULL),
(11, 4725, 314, 11427, NULL, NULL, NULL),
(15, 4726, NULL, NULL, NULL, NULL, 2),
(14, 4726, NULL, 11432, 2126, 656, NULL),
(13, 4726, 312, 11428, 2122, 652, NULL),
(16, 4727, 315, 11430, 2124, 654, NULL),
(17, 4728, NULL, 11431, 2125, 655, NULL),
(18, 4729, NULL, 11426, 2121, 651, NULL),
(19, 4730, NULL, 11425, 2120, 650, NULL),
(20, 4731, NULL, NULL, NULL, NULL, NULL),
(21, 4732, NULL, 11423, 2118, 648, NULL),
(22, 4733, NULL, 11424, 2128, 649, NULL),
(23, 4734, 316, 11433, 2127, 657, NULL);

-- --------------------------------------------------------

--
-- Stand-in structure for view `patients appointments with chw`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `patients appointments with chw`;
CREATE TABLE IF NOT EXISTS `patients appointments with chw` (
`patientID` int(5)
,`fname` varchar(30)
,`appointmentType` varchar(15)
,`date` date
,`time` time
);

-- --------------------------------------------------------

--
-- Table structure for table `pharmacy`
--

DROP TABLE IF EXISTS `pharmacy`;
CREATE TABLE IF NOT EXISTS `pharmacy` (
  `pharmacyID` int(5) NOT NULL AUTO_INCREMENT COMMENT 'unique identifier',
  `location` varchar(35) NOT NULL COMMENT 'location of pharmacy',
  `pharmacist` varchar(35) NOT NULL COMMENT 'personnel responsible for distribution of medication',
  PRIMARY KEY (`pharmacyID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COMMENT='pharmacy details';

--
-- Dumping data for table `pharmacy`
--

INSERT INTO `pharmacy` (`pharmacyID`, `location`, `pharmacist`) VALUES
(3, 'Ground Floor, Main Building', 'Jerry Steinfeld');

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

DROP TABLE IF EXISTS `prescription`;
CREATE TABLE IF NOT EXISTS `prescription` (
  `prescriptionID` int(5) NOT NULL AUTO_INCREMENT COMMENT 'unique identifier',
  `patientID` int(5) NOT NULL COMMENT 'patient to receive medication',
  `medication` varchar(35) NOT NULL COMMENT 'name of medication',
  `dosage` varchar(35) NOT NULL COMMENT 'how many to be taken',
  `frequency` varchar(35) NOT NULL COMMENT 'how often it should be taken',
  `dateOfPrescription` date NOT NULL COMMENT 'date prescribed',
  PRIMARY KEY (`prescriptionID`),
  KEY `patientID` (`patientID`)
) ENGINE=InnoDB AUTO_INCREMENT=660 DEFAULT CHARSET=latin1 COMMENT='information of prescription';

--
-- Dumping data for table `prescription`
--

INSERT INTO `prescription` (`prescriptionID`, `patientID`, `medication`, `dosage`, `frequency`, `dateOfPrescription`) VALUES
(642, 4720, 'Ambien(zolpidem)', '10mg per tablet', 'once every night', '2020-03-15'),
(643, 4721, 'MiraLax', '119grams', '7 once-daily', '2020-03-16'),
(644, 4722, 'Amoxil (amoxicillin)', '500mg', 'once every 8 hours', '2020-03-15'),
(645, 4720, 'ibuprofen', '200mg', '4 – 6 hours as needed', '2020-03-18'),
(646, 4723, 'Zyrtec-D', '120 Mg', 'twice daily', '2020-03-16'),
(647, 4724, 'Rifafour', '400mg', '5 daily', '2020-03-16'),
(648, 4732, 'metformin', '500mg', '1-3x daily', '2020-03-16'),
(649, 4733, 'agrylin', '0.5mg', 'daily', '2020-03-16'),
(650, 4730, 'Zyrtec-D', '120 Mg', 'twice daily', '2020-03-16'),
(651, 4729, 'Zyrtec-D', '120 Mg', 'twice daily', '2020-03-16'),
(652, 4726, 'Ambien(zolpidem)', '10mg per tablet', 'once every night', '2020-03-17'),
(653, 4725, 'metformin', '500mg', '1-3x daily', '2020-03-17'),
(654, 4727, 'ibuprofen', '200mg', '4 – 6 hours as needed', '2020-03-17'),
(655, 4728, 'MiraLax', '119grams', '7 once-daily', '2020-03-17'),
(656, 4726, 'ibuprofen', '200mg', '4 – 6 hours as needed', '2020-03-17'),
(657, 4734, 'agrylin', '0.5mg', 'daily', '2020-03-17');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
CREATE TABLE IF NOT EXISTS `room` (
  `roomNo` int(3) NOT NULL AUTO_INCREMENT COMMENT 'unique identifier of room',
  `roomType` varchar(30) NOT NULL COMMENT 'room for which department',
  `assignedTo` int(5) DEFAULT NULL COMMENT 'staff occupying room',
  PRIMARY KEY (`roomNo`),
  KEY `assignedTo` (`assignedTo`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COMMENT='details of room';

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`roomNo`, `roomType`, `assignedTo`) VALUES
(1, 'consulting room', 3221),
(2, 'consulting room', 3222),
(3, 'consulting room', 3223),
(4, 'lab', 3233),
(5, 'lab', 3234),
(6, 'lab', 3235),
(7, 'radiology lab', 3230),
(8, 'radiology lab', 3231),
(9, 'radiology lab', 3232),
(11, 'radiology lab', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
CREATE TABLE IF NOT EXISTS `staff` (
  `staffID` int(5) NOT NULL AUTO_INCREMENT COMMENT 'unique identifier',
  `fname` varchar(30) NOT NULL COMMENT 'first name',
  `lname` varchar(30) NOT NULL COMMENT 'last name',
  `email` varchar(50) NOT NULL COMMENT 'email address',
  `position` varchar(15) NOT NULL COMMENT 'job titile',
  `salary` decimal(8,2) NOT NULL COMMENT 'salary',
  PRIMARY KEY (`staffID`)
) ENGINE=InnoDB AUTO_INCREMENT=3236 DEFAULT CHARSET=latin1 COMMENT='All staff members of all roles';

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staffID`, `fname`, `lname`, `email`, `position`, `salary`) VALUES
(3221, 'Tracey-lee', 'Olivier', 'traceyleeolivier@broadreach.com', 'clinician', '37000.00'),
(3222, 'Maria', 'Cox', 'mariacox@broadreach.com', 'clinician', '32000.00'),
(3223, 'Cecli', 'Hernandez', 'cecilhernandez@broadreach.com', 'clinician', '32000.00'),
(3224, 'Francis', 'Harris', 'francisharris@broadreach.com', 'receptionist', '12600.00'),
(3225, 'Shirani', 'Rose', 'shiranirose@broadreach.com', 'receptionist', '12600.00'),
(3226, 'Suzette', 'Rogers', 'suzetterogers@broadreach.com', 'receptionist', '12600.00'),
(3227, 'Renee', 'Baker', 'reneebaker@broadreach.com', 'CHW', '8400.00'),
(3228, 'Haley', 'Smyth', 'haleySmyth@broadreach.com', 'CHW', '8400.00'),
(3229, 'Erik', 'Moore', 'erikm@broadreach.com', 'CHW', '8400.00'),
(3230, 'Roald', 'Ramirez', 'roaldramirez@broadreach.com', 'radiologist', '21700.00'),
(3231, 'Cleo', 'Ramos', 'cleoramos@broadreach.com', 'radiologist', '21700.00'),
(3232, 'Nathaniel', 'Doherty', 'natedoherty@broadreach.com', 'radiologist', '21700.00'),
(3233, 'Paisley', 'Lopez', 'paisleylopez@broadreach.com', 'lab worker', '20340.00'),
(3234, 'Timothy', 'Alexander', 'timalexander@broadreach.com', 'lab worker', '20340.00'),
(3235, 'Joseph', 'White', 'josephwhite@broadreach.com', 'lab worker', '20340.00');

-- --------------------------------------------------------

--
-- Table structure for table `treatment`
--

DROP TABLE IF EXISTS `treatment`;
CREATE TABLE IF NOT EXISTS `treatment` (
  `treatmentID` int(5) NOT NULL AUTO_INCREMENT COMMENT 'unique identifier',
  `patientID` int(5) NOT NULL COMMENT 'patient to receive treatment',
  `treatmentType` varchar(35) NOT NULL COMMENT 'category of treatment',
  PRIMARY KEY (`treatmentID`),
  KEY `patientID` (`patientID`)
) ENGINE=InnoDB AUTO_INCREMENT=2135 DEFAULT CHARSET=latin1 COMMENT='information of treatment';

--
-- Dumping data for table `treatment`
--

INSERT INTO `treatment` (`treatmentID`, `patientID`, `treatmentType`) VALUES
(2112, 4720, 'Clinical Trial'),
(2113, 4721, 'Clinical Trial'),
(2114, 4722, 'Immunotherapy'),
(2115, 4720, 'Clinical Trial'),
(2116, 4723, 'Clinical Trial'),
(2117, 4724, 'Clinical Trial'),
(2118, 4732, 'Clinical Trial'),
(2119, 4723, 'Clinical Trial'),
(2120, 4730, 'Clinical Trial'),
(2121, 4729, 'Clinical Trial'),
(2122, 4726, 'Clinical Trial'),
(2123, 4725, 'Clinical Trial'),
(2124, 4727, 'Radiation Therapy'),
(2125, 4728, 'Clinical Trial'),
(2126, 4726, 'Clinical Trial'),
(2127, 4734, 'Chemo Therapy'),
(2128, 4733, 'Clinical Trial'),
(2131, 4733, 'clinical trial'),
(2132, 4734, 'clinical trial');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `userID` int(5) NOT NULL AUTO_INCREMENT,
  `fullName` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `userType` varchar(20) NOT NULL,
  PRIMARY KEY (`userID`)
) ENGINE=InnoDB AUTO_INCREMENT=3229 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `fullName`, `password`, `userType`) VALUES
(3221, 'Tracey-lee Olivier', 'tr@1997#broadreach', 'clinician'),
(3222, 'Maria Cox', 'cox@broadreach', 'clinician'),
(3223, 'cecli hernandez', 'cece#123', 'clinician'),
(3224, 'Francis Harris', 'frans202', 'receptionist'),
(3227, 'Renee Baker', 'baker#654', 'CHW'),
(3231, 'Cleo Ramos', '7785Ray', 'radiologist'),
(3233, 'Paisley Lopez', 'lopez2002', 'Lab Worker'),
(4720, 'Brandy Spotts', 'mother1331', 'patient');

-- --------------------------------------------------------

--
-- Table structure for table `video`
--

DROP TABLE IF EXISTS `video`;
CREATE TABLE IF NOT EXISTS `video` (
  `videoID` int(5) NOT NULL AUTO_INCREMENT COMMENT 'unique identifier of video',
  `name` varchar(35) NOT NULL COMMENT 'name of video',
  `path` varchar(255) NOT NULL COMMENT 'location of video file',
  `description` varchar(255) DEFAULT NULL COMMENT 'description of video file',
  PRIMARY KEY (`videoID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COMMENT='information of video files';

--
-- Dumping data for table `video`
--

INSERT INTO `video` (`videoID`, `name`, `path`, `description`) VALUES
(1, 'Diabetes mellitus', '<iframe width=\"120\" height=\"120\" src=\"https://www.youtube.com/embed/-B-RVybvffU\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', 'What is diabetes mellitus?'),
(2, 'Building a baby', '<iframe width=\"120\" height=\"120\" src=\"https://www.youtube.com/embed/9AX1XwKCYQE\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', 'The first few weeks of an embryo\'s development are vital. Now, new techniques are allowing scientists to learn more about this crucial time than ever before.');

-- --------------------------------------------------------

--
-- Structure for view `all diagnostic test details`
--
DROP TABLE IF EXISTS `all diagnostic test details`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `all diagnostic test details`  AS  select `diagnostictest`.`testID` AS `testID`,`diagnostictest`.`testType` AS `testType`,`diagnostictest`.`testConductor` AS `testConductor`,`diagnostictest`.`roomNo` AS `roomNo`,`diagnostictest`.`patientID` AS `patientID`,`patient`.`fname` AS `fname`,`diagnostictest`.`comments` AS `comments`,`diagnostictest`.`date` AS `date`,`diagnostictest`.`time` AS `time` from (`diagnostictest` join `patient` on((`diagnostictest`.`patientID` = `patient`.`patientID`))) ;

-- --------------------------------------------------------

--
-- Structure for view `all patient appointments in detail`
--
DROP TABLE IF EXISTS `all patient appointments in detail`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `all patient appointments in detail`  AS  select `appointment`.`appointmentID` AS `appointmentID`,`appointment`.`appointmentType` AS `appointmentType`,`appointment`.`date` AS `date`,`appointment`.`time` AS `time`,`patient`.`patientID` AS `patientID`,`patient`.`fname` AS `fname`,`staff`.`staffID` AS `staffID`,`staff`.`lname` AS `lname` from ((`appointment` join `patient` on((`appointment`.`patientID` = `patient`.`patientID`))) join `staff` on((`appointment`.`chwID` = `staff`.`staffID`))) ;

-- --------------------------------------------------------

--
-- Structure for view `patients appointments with chw`
--
DROP TABLE IF EXISTS `patients appointments with chw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `patients appointments with chw`  AS  select `patient`.`patientID` AS `patientID`,`patient`.`fname` AS `fname`,`appointment`.`appointmentType` AS `appointmentType`,`appointment`.`date` AS `date`,`appointment`.`time` AS `time` from ((`appointment` join `patient` on((`appointment`.`patientID` = `patient`.`patientID`))) join `staff` on((`appointment`.`chwID` = `staff`.`staffID`))) ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointment`
--
ALTER TABLE `appointment`
  ADD CONSTRAINT `chwID` FOREIGN KEY (`chwID`) REFERENCES `staff` (`staffID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `patientID` FOREIGN KEY (`patientID`) REFERENCES `patient` (`patientID`) ON UPDATE CASCADE;

--
-- Constraints for table `diagnostictest`
--
ALTER TABLE `diagnostictest`
  ADD CONSTRAINT `patientofAppointment` FOREIGN KEY (`patientID`) REFERENCES `patient` (`patientID`),
  ADD CONSTRAINT `roomNo` FOREIGN KEY (`roomNo`) REFERENCES `room` (`roomNo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `testConductor` FOREIGN KEY (`testConductor`) REFERENCES `staff` (`staffID`);

--
-- Constraints for table `examination`
--
ALTER TABLE `examination`
  ADD CONSTRAINT `examinerNo` FOREIGN KEY (`examinerID`) REFERENCES `staff` (`staffID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `patientNo` FOREIGN KEY (`patientID`) REFERENCES `patient` (`patientID`) ON UPDATE CASCADE;

--
-- Constraints for table `intervention`
--
ALTER TABLE `intervention`
  ADD CONSTRAINT `patientsIntervention` FOREIGN KEY (`patientID`) REFERENCES `patient` (`patientID`) ON UPDATE CASCADE;

--
-- Constraints for table `message`
--
ALTER TABLE `message`
  ADD CONSTRAINT `chwMessage` FOREIGN KEY (`chwID`) REFERENCES `staff` (`staffID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `patientsMessage` FOREIGN KEY (`patientID`) REFERENCES `patient` (`patientID`) ON UPDATE CASCADE;

--
-- Constraints for table `patientexaminationrecord`
--
ALTER TABLE `patientexaminationrecord`
  ADD CONSTRAINT `examReference` FOREIGN KEY (`examID`) REFERENCES `examination` (`examID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `patientExamRecord` FOREIGN KEY (`patientID`) REFERENCES `patient` (`patientID`) ON UPDATE CASCADE;

--
-- Constraints for table `patientlist`
--
ALTER TABLE `patientlist`
  ADD CONSTRAINT `appointmentScheduled` FOREIGN KEY (`appointmentID`) REFERENCES `appointment` (`appointmentID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `chwOfPatient` FOREIGN KEY (`chwID`) REFERENCES `staff` (`staffID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `patientOnList` FOREIGN KEY (`patientID`) REFERENCES `patient` (`patientID`) ON UPDATE CASCADE;

--
-- Constraints for table `patientrecord`
--
ALTER TABLE `patientrecord`
  ADD CONSTRAINT `examRef` FOREIGN KEY (`examID`) REFERENCES `examination` (`examID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `interventionRef` FOREIGN KEY (`interventionID`) REFERENCES `intervention` (`interventionID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `prescriptionRef` FOREIGN KEY (`prescriptionID`) REFERENCES `prescription` (`prescriptionID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `specificPatient` FOREIGN KEY (`patientID`) REFERENCES `patient` (`patientID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `testRef` FOREIGN KEY (`testID`) REFERENCES `diagnostictest` (`testID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `treatmentRef` FOREIGN KEY (`treatmentID`) REFERENCES `treatment` (`treatmentID`) ON UPDATE CASCADE;

--
-- Constraints for table `prescription`
--
ALTER TABLE `prescription`
  ADD CONSTRAINT `PrescriptionFor` FOREIGN KEY (`patientID`) REFERENCES `patient` (`patientID`) ON UPDATE CASCADE;

--
-- Constraints for table `room`
--
ALTER TABLE `room`
  ADD CONSTRAINT `StaffAssigned` FOREIGN KEY (`assignedTo`) REFERENCES `staff` (`staffID`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `treatment`
--
ALTER TABLE `treatment`
  ADD CONSTRAINT `treatmentReceiver` FOREIGN KEY (`patientID`) REFERENCES `patient` (`patientID`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
